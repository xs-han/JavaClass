//7. AIRobot.java
package com.robot.www;
import java.io.*;
import java.lang.*;
public class AIRobot extends SuperMan implements Hulk,WarRobot{
    private int humanity;
    public void setHumanity(int h){
        humanity=h;
    }
    public void thinkOf(){
        System.out.println("I can think.");
    }
    public int  putHumanity(){
        return humanity;
    }
    public String judge(){
        return "I can judge.";
    }
    public void attack(){
        System.out.println("I can attack.");
    }
    public void transform(){
        System.out.println("I can transform.");
    }   
    public void defense(){
        System.out.println("I can defense.");
    } 
    public void fire(){
        System.out.println("I can fire.");
    }   
    public void knife(){
        System.out.println("I can fight.");
    } 
    public void general(){
        System.out.println("I can use general method.");
    }   
    public void nightFly(){
        System.out.println("I can nightFly.");
    } 
    public void jump(){
        System.out.println("I can jump.");    } 
    }
