//5.WarRobot.java
package com.robot.www;

import java.io.*;
import java.lang.*;

public interface WarRobot extends CaptainAmerica,BatMan,IronMan{
    public final int weapon=5;
    public abstract void fire();
    public abstract void knife();
}