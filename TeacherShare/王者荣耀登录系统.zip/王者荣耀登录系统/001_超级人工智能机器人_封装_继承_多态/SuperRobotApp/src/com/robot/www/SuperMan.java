//1. SuperMan.java
package com.robot.www;

import java.io.*;
import java.lang.*;

public abstract class SuperMan{
  protected String id;
  protected int superAbility;
  public void setID(String i){
    id=i;
  }
  public void setSA(int sa){
    superAbility=sa;
  }
  public abstract String judge();
  public String putID(){
     return id;
  }
  public int putSA(){
     return superAbility;
  }
}