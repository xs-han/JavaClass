//6.Hulk.java
package com.robot.www;

import java.io.*;
import java.lang.*;

public interface Hulk{
    public final int trigger=100;
    public abstract void attack();
    public abstract void transform();
    public abstract void defense();
}