//4. IronMan.java
package com.robot.www;

import java.io.*;
import java.lang.*;

public interface IronMan{
    public final int jumpDirection=8;
    public abstract void jump();
}