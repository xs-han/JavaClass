//3. BatMan.java

package com.robot.www;

import java.io.*;
import java.lang.*;

public interface BatMan{
   public final int flyAngle=150;
   public abstract void nightFly();
}