//2. CaptainAmerica.java

package com.robot.www;

import java.io.*;
import java.lang.*;

public interface CaptainAmerica{
    public final int kongfu=6;
    public abstract void general();  

}