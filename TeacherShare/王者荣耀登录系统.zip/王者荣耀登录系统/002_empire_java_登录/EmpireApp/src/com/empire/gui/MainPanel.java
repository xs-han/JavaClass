package com.empire.gui;
import java.lang.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;

public class MainPanel extends JPanel{
	NorthPanel np=new NorthPanel();
	CenterPanel cp=new CenterPanel();
	SouthPanel sp=new SouthPanel();
    BorderLayout bl=new BorderLayout(5,5);
    
	 public MainPanel(){
		 this.setBackground(Color.pink);
		 this.setLayout(bl);
		 this.add("North",np);
		 this.add("Center",cp);
		 this.add("South",sp);
	 }
}