package com.empire.gui;

import java.lang.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;

public class MainProgram{
   public static void main(String [] args){
       MainWindow mw=new MainWindow();
       mw.setTitle("������ҫ��¼ϵͳ");
       mw.setBounds(300,400,350,280);
       mw.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       mw.setVisible(true);
   }
}