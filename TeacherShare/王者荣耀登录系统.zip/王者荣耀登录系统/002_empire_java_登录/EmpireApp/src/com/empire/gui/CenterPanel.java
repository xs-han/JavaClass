package com.empire.gui;
import java.lang.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;

public class CenterPanel extends JPanel{

	ImageIcon imgCheckCode=new ImageIcon("checkcode.jpg");
	JLabel lblUserName=new JLabel("�û�����",JLabel.CENTER);
	JLabel lblPwd1=new JLabel("��  �룺",JLabel.CENTER);
	JLabel lblPwd2=new JLabel("����ȷ�ϣ�",JLabel.CENTER);
	JLabel lblCheckCode=new JLabel(imgCheckCode,JLabel.CENTER);
	
	JTextField txtUserName=new JTextField(20);
	JPasswordField txtPwd1=new JPasswordField(20);
	JPasswordField txtPwd2=new JPasswordField(20);
	JTextField txtCheckCode=new JTextField(20);
	
	GridLayout gl=new GridLayout(4,2,5,5);
	
	public CenterPanel(){
		this.setBackground(Color.yellow);
		this.setLayout(gl);
		this.add(lblUserName);
		this.add(txtUserName);
		this.add(lblPwd1);
		this.add(txtPwd1);
		this.add(lblPwd2);
		this.add(txtPwd2);
		this.add(lblCheckCode);
		this.add(txtCheckCode);
	}  
}