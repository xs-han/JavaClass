package com.empire.gui;
import java.lang.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;
public class SouthPanel extends JPanel{
	
	JButton btnLogin=new JButton("��¼");
	JButton btnCancel=new JButton("ȡ��");
	JButton btnRegister=new JButton("���û�ע��");
	FlowLayout fl=new FlowLayout(FlowLayout.CENTER,5,5);
	
	public SouthPanel(){
		this.setBackground(Color.blue);
		this.setLayout(fl);
		this.add(btnLogin);
		this.add(btnCancel);
		this.add(btnRegister);
	}  
}